const React = require('react-native');

const { StyleSheet, Dimensions,Platform } = React;

export default{
  footerIcon: {
  	marginTop: 0,
  	color: '#ccc',
  	lineHeight: 30,
  	height: 30,
  	marginLeft: 10,
    paddingLeft: 5,
    paddingRight: 5,
  	marginRight: 10
  },
};
