

const React = require('react-native');

const { StyleSheet } = React;

export default{
  container: {
    flex: 1,
    width: null,
    height: null,
  },
};
